package module;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.xdevapi.Statement;

public class MainPage2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtProfile;
	private JButton HomeButton;
	private JButton PostButton;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTextField nameOfUserTF;
	private JTextField usernameTF;
	private JTextField mailTF;
	private JButton Friend;

	private JTable table_1;
	private JTable table;
	String nameOfUser;
	String username;
	String mail;

	/**
	 * Launch the application.
	 */

	public MainPage2(String username) {

		this.username = username;
		try {
			// Connect
			// Database connection details
			String url = "jdbc:mysql://localhost:3306/javap";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url, user, pass);

			// Prepare statement
			PreparedStatement st = con.prepareStatement("SELECT * FROM signup WHERE username=? ");
			st.setString(1, username);

			// Execute statement
			ResultSet rs = st.executeQuery();

			// Check if user exists
			if (rs.next()) {
				nameOfUser = rs.getString(1);
				mail=rs.getString(2);
				System.out.println(mail);
				

			} else {
				System.out.println("Error: rs is empty ");
			}

			// Close connections
			st.close();
			con.close();

		} catch (SQLException ex) {
			System.out.println("Error: " + ex.getMessage());
		}

		setResizable(false);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 644, 477);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(235, 221, 236));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		lblNewLabel_1 = new JLabel("Profile");
		lblNewLabel_1.setBounds(134, 50, 179, 33);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 28));
		contentPane.add(lblNewLabel_1);

		lblNewLabel = new JLabel("Thrive");
		lblNewLabel.setBounds(20, 53, 89, 35);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		contentPane.add(lblNewLabel);

		btnNewButton_3 = new JButton("Log Out");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		btnNewButton_3.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton_3.setBounds(20, 374, 89, 23);
		contentPane.add(btnNewButton_3);

		btnNewButton_2 = new JButton("Friends");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				MainPage4 mp4 = new MainPage4(username);
				mp4.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(20, 272, 89, 23);
		btnNewButton_2.setFont(new Font("Calisto MT", Font.BOLD, 14));
		contentPane.add(btnNewButton_2);

		PostButton = new JButton("Post");
		PostButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				MainPage3 mp3 = new MainPage3(username);
				mp3.setVisible(true);

			}
		});
		PostButton.setBounds(20, 201, 89, 23);
		PostButton.setFont(new Font("Calisto MT", Font.BOLD, 14));
		contentPane.add(PostButton);

		HomeButton = new JButton("Home");
		HomeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				MainPage mp = new MainPage(username);
				mp.setVisible(true);

			}
		});
		HomeButton.setBounds(20, 135, 89, 23);
		HomeButton.setFont(new Font("Calisto MT", Font.BOLD, 14));
		contentPane.add(HomeButton);

		textField = new JTextField();
		textField.setBounds(0, 0, 124, 447);
		textField.setBackground(new Color(64, 0, 64));
		contentPane.add(textField);
		textField.setColumns(10);

		txtProfile = new JTextField();
		txtProfile.setBounds(121, 0, 515, 97);
		txtProfile.setFont(new Font("Times New Roman", Font.BOLD, 22));
		txtProfile.setBackground(new Color(199, 159, 202));
		contentPane.add(txtProfile);
		txtProfile.setColumns(10);

		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Vedanshi Sahu\\Downloads\\My project (1).jpg"));
		lblNewLabel_2.setBounds(134, 132, 124, 114);
		contentPane.add(lblNewLabel_2);

		nameOfUserTF = new JTextField();
		nameOfUserTF.setText(nameOfUser);
		nameOfUserTF.setBounds(287, 135, 224, 20);
		contentPane.add(nameOfUserTF);
		nameOfUserTF.setColumns(10);
		nameOfUserTF.setEditable(false);

		usernameTF = new JTextField();
		usernameTF.setText(username);
		usernameTF.setForeground(new Color(64, 0, 64));
		usernameTF.setBounds(287, 177, 224, 20);
		contentPane.add(usernameTF);
		usernameTF.setColumns(10);
		usernameTF.setEditable(false);

		mailTF = new JTextField();
		mailTF.setText(mail);
		mailTF.setBounds(287, 213, 224, 20);
		contentPane.add(mailTF);
		mailTF.setColumns(10);
		mailTF.setEditable(false);

		JButton friendList = new JButton("Friend List");
		friendList.setFont(new Font("Calisto MT", Font.BOLD, 15));
		friendList.setBounds(134, 311, 126, 33);
		contentPane.add(friendList);

		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Friends");
		
		
	

		friendList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// Connect to the database
					String url = "jdbc:mysql://localhost:3306/javap";
					String user = "root";
					String pass = "root";
					Connection con = DriverManager.getConnection(url, user, pass);

					// Prepare statement to get the list of friends
					String tableName = username + "_Friends";
					PreparedStatement st = con.prepareStatement("SELECT * FROM " + tableName);

					// Execute statement and get the result set
					ResultSet rs = st.executeQuery();

					// Create a new JFrame to show the list of usernames
					JFrame frame = new JFrame("Friends");
					frame.setBounds(100, 100, 400, 300);

					// Create a new JTable to show the result set
					JTable table = new JTable();
					JScrollPane scrollPane = new JScrollPane(table);
					frame.getContentPane().add(scrollPane);
					DefaultTableModel model = new DefaultTableModel(new Object[] { "Username" }, 0);
					while (rs.next()) {
						String friend = rs.getString("friends");
						model.addRow(new Object[] { friend });
					}
					table.setModel(model);

					// Show the JFrame
					frame.setVisible(true);

					// Close connections
					st.close();
					con.close();
				} catch (SQLException ex) {
					System.out.println("Error: " + ex.getMessage());
				}

			}
		});

		Friend = new JButton("Add Friend");
		Friend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String friendUsername = JOptionPane.showInputDialog("Enter your friend's username:");

				try {
					// Connect
					String url = "jdbc:mysql://localhost:3306/javap";
					String user = "root";
					String pass = "root";
					Connection con = DriverManager.getConnection(url, user, pass);

					// Check if friend's username exists in signup table
					PreparedStatement st = con.prepareStatement("SELECT * FROM signup WHERE username=?");
					st.setString(1, friendUsername);
					ResultSet rs = st.executeQuery();

					if (rs.next()) {
						// If friend's username exists, insert the username into username_friends table
						PreparedStatement st2 = con
								.prepareStatement("INSERT INTO " + username + "_friends (friends) VALUES (?)");
						st2.setString(1, friendUsername);
						st2.executeUpdate();
						st2.close();
						JOptionPane.showMessageDialog(contentPane, "Friend added successfully!");
					} else {
						JOptionPane.showMessageDialog(contentPane, "The username does not exist.");
					}

					// Close connections
					st.close();
					con.close();

				} catch (SQLException ex) {
					System.out.println("Error: " + ex.getMessage());
				}
			}
		});
		Friend.setFont(new Font("Calisto MT", Font.BOLD, 14));
		Friend.setBounds(134, 355, 124, 23);
		contentPane.add(Friend);

		

		
		
		JButton showPostButton1 = new JButton("Show Post");
		showPostButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Connect to the database
				// Get the name of the table for the current user
				String tableName = username + "_post";

				try {
					// Connect to the database
					String url = "jdbc:mysql://localhost:3306/javap";
					String user = "root";
					String pass = "root";
					Connection con = DriverManager.getConnection(url, user, pass);

					// Prepare a statement to select all rows from the table
					String sql = "SELECT * FROM " + tableName;
					PreparedStatement st = con.prepareStatement(sql);

					// Execute the statement and get the result set
					ResultSet rs = st.executeQuery(sql);

					// Create a table model and add columns
					DefaultTableModel tableModel = new DefaultTableModel();
					tableModel.addColumn("Post");

					// Loop through the result set and add each row to the table model
					while (rs.next()) {
						String post = rs.getString("post");
						Object[] row = { post };
						tableModel.addRow(row);
					}

					// Close the statement, result set, and connection
					rs.close();
					st.close();
					con.close();

					// Create a JTable with the table model and add it to a JScrollPane
					JTable table = new JTable(tableModel);
					JScrollPane scrollPane = new JScrollPane(table);

					// Show the JScrollPane in a dialog
					JOptionPane.showMessageDialog(contentPane, scrollPane, "Post Table", JOptionPane.PLAIN_MESSAGE);

				} catch (SQLException ex) {
					// Display an error message if there was an exception
					JOptionPane.showMessageDialog(contentPane, "Error: " + ex.getMessage(), "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

			
		showPostButton1.setFont(new Font("Calisto MT", Font.BOLD, 15));
		showPostButton1.setBounds(439, 315, 112, 23);
		contentPane.add(showPostButton1);

	}
}
