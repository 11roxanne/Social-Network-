package module;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainPage4 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField AddFriendTF;
	private JTextField removeTF;
	private JTextField searchTF;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public MainPage4(String username) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 489);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 215, 232));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNewButton_6 = new JButton(" Search ");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String url = "jdbc:mysql://localhost:3306/javap";
				String user = "root";
				String pass= "root";

				String search = searchTF.getText();

				try {
					Class.forName("com.mysql.cj.jdbc.Driver"); // Driver load

					Connection con = DriverManager.getConnection(url, user, pass);

					String query = "select * from "+username+"_friends";

					Statement st = con.createStatement();

					ResultSet rs = st.executeQuery(query);
					int flag=0;
					while(rs.next()) {
						String friend = rs.getString("Friends");

						if (friend.equals(search)) {
							JOptionPane.showMessageDialog(null, "Friend found");
							flag=1;
						} 
					}
					if(flag==0)
					{
						
							JOptionPane.showMessageDialog(null, "Friend not found");
						
					}

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

			}
		});
		btnNewButton_6.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton_6.setBounds(391, 360, 89, 23);
		contentPane.add(btnNewButton_6);

		JButton btnNewButton_5 = new JButton("Remove");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "jdbc:mysql://localhost:3306/javap";
					String user = "root";
					String pass= "root";

					String Frndname = AddFriendTF.getText();

					Class.forName("com.mysql.cj.jdbc.Driver"); // Driver load

					Connection con = DriverManager.getConnection(url, user, pass);
					String sql = "DELETE FROM "+username+"_friends WHERE Friends = ?";
					PreparedStatement pst = con.prepareStatement(sql);
					pst.setString(1, removeTF.getText());
					pst.execute();

					JOptionPane.showMessageDialog(null, "Friend deleted");
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}

			}

		});
		btnNewButton_5.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton_5.setBounds(391, 270, 89, 23);
		contentPane.add(btnNewButton_5);

		JButton btnNewButton_4 = new JButton(" Add");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String friendUsername = AddFriendTF.getText();

				try {
					// Connect
					String url = "jdbc:mysql://localhost:3306/javap";
					String user = "root";
					String pass = "root";
					Connection con = DriverManager.getConnection(url, user, pass);

					// Check if friend's username exists in signup table
					PreparedStatement st = con.prepareStatement("SELECT * FROM signup WHERE username=?");
					st.setString(1, friendUsername);
					ResultSet rs = st.executeQuery();

					if (rs.next()) {
						// If friend's username exists, insert the username into username_friends table
						PreparedStatement st2 = con
								.prepareStatement("INSERT INTO " + username + "_friends (friends) VALUES (?)");
						st2.setString(1, friendUsername);
						st2.executeUpdate();
						st2.close();
						JOptionPane.showMessageDialog(contentPane, "Friend added successfully!");
					} else {
						JOptionPane.showMessageDialog(contentPane, "The username does not exist.");
					}

					// Close connections
					st.close();
					con.close();

				} catch (SQLException ex) {
					System.out.println("Error: " + ex.getMessage());
				}
			}
		});
		btnNewButton_4.setFont(new Font("Calisto MT", Font.BOLD, 15));
		btnNewButton_4.setBounds(391, 195, 89, 23);
		contentPane.add(btnNewButton_4);

		searchTF = new JTextField();
		searchTF.setBounds(361, 329, 153, 20);
		contentPane.add(searchTF);
		searchTF.setColumns(10);

		removeTF = new JTextField();
		removeTF.setBounds(361, 239, 153, 20);
		contentPane.add(removeTF);
		removeTF.setColumns(10);

		AddFriendTF = new JTextField();
		AddFriendTF.setBounds(361, 161, 153, 20);
		contentPane.add(AddFriendTF);
		AddFriendTF.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel(" Search Friends ");
		lblNewLabel_4.setFont(new Font("Calisto MT", Font.BOLD, 18));
		lblNewLabel_4.setBounds(177, 323, 164, 35);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_3 = new JLabel("Remove Friends ");
		lblNewLabel_3.setFont(new Font("Calisto MT", Font.BOLD, 18));
		lblNewLabel_3.setBounds(177, 233, 141, 35);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_2 = new JLabel("Add Friends ");
		lblNewLabel_2.setFont(new Font("Calisto MT", Font.BOLD, 18));
		lblNewLabel_2.setBounds(177, 161, 125, 23);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_1 = new JLabel(" Friends ");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 28));
		lblNewLabel_1.setBounds(120, 38, 141, 35);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel = new JLabel("  Thrive");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setBounds(0, 37, 100, 35);
		contentPane.add(lblNewLabel);

		JButton btnNewButton_2 = new JButton("Post");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				MainPage3 mp3 = new MainPage3(username);
				mp3.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton_2.setBounds(10, 257, 89, 23);
		contentPane.add(btnNewButton_2);

		JButton btnNewButton_1 = new JButton("Profile");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage4 mp4 = new MainPage4(username);
				mp4.dispose();
				MainPage2 mp2 = new MainPage2(username);
				mp2.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton_1.setBounds(10, 196, 89, 23);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton = new JButton("Home");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage4 mp4 = new MainPage4(username);
				mp4.dispose();
				MainPage mp = new MainPage(username);
				mp.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton.setBounds(10, 129, 89, 23);
		contentPane.add(btnNewButton);

		JButton btnNewButton_3 = new JButton("Log Out");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage4 mp4 = new MainPage4(username);
				mp4.dispose();

			}
		});
		btnNewButton_3.setFont(new Font("Calisto MT", Font.BOLD, 14));
		btnNewButton_3.setBounds(10, 380, 89, 23);
		contentPane.add(btnNewButton_3);

		textField = new JTextField();
		textField.setBackground(new Color(64, 0, 64));
		textField.setBounds(0, 0, 110, 452);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBackground(new Color(185, 149, 182));
		textField_1.setBounds(110, 0, 567, 86);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBackground(new Color(202, 174, 200));
		textField_2.setBounds(139, 130, 469, 274);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
	}
}
